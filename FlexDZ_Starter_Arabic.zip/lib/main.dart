import 'package:flutter/material.dart';

void main() => runApp(const FlexDzApp());

const ink = Color(0xFF14231F);
const green = Color(0xFF087F5B);
const mint = Color(0xFFE7F6EF);
const canvas = Color(0xFFF6F8F7);

class FlexDzApp extends StatelessWidget {
  const FlexDzApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FlexDZ',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: canvas,
        colorScheme: ColorScheme.fromSeed(seedColor: green),
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(
          backgroundColor: canvas, foregroundColor: ink, elevation: 0,
          centerTitle: false,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true, fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFE2E9E5)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFE2E9E5)),
          ),
        ),
      ),
      home: const WelcomeScreen(),
    );
  }
}

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Spacer(),
              Container(
                height: 84, width: 84,
                decoration: BoxDecoration(color: green, borderRadius: BorderRadius.circular(26)),
                child: const Icon(Icons.bolt_rounded, color: Colors.white, size: 48),
              ),
              const SizedBox(height: 24),
              const Text('FlexDZ', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, color: ink)),
              const SizedBox(height: 8),
              const Text('تعبئة الرصيد بطريقة بسيطة', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w600)),
              const SizedBox(height: 10),
              const Text(
                'نموذج أولي لتطبيق فليكسي جزائري. اختر الواجهة التي تريد تجربتها.',
                style: TextStyle(color: Colors.black54, height: 1.6),
              ),
              const SizedBox(height: 30),
              FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: green, padding: const EdgeInsets.symmetric(vertical: 17)),
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CustomerHome())),
                icon: const Icon(Icons.person_outline),
                label: const Text('الدخول كزبون'),
              ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 17)),
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AgentHome())),
                icon: const Icon(Icons.storefront_outlined),
                label: const Text('الدخول كوكيل (عرض تجريبي)'),
              ),
              const Spacer(),
              const Text('نسخة تجريبية — لا تنفّذ تعبئة حقيقية ولا تحفظ بيانات الحسابات.',
                textAlign: TextAlign.center, style: TextStyle(color: Colors.black45, fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}

class CustomerHome extends StatefulWidget {
  const CustomerHome({super.key});
  @override
  State<CustomerHome> createState() => _CustomerHomeState();
}

class _CustomerHomeState extends State<CustomerHome> {
  String network = 'موبيليس';
  final phone = TextEditingController();
  final amount = TextEditingController(text: '500');
  int balance = 2000;
  final List<Map<String, String>> history = [
    {'title': 'شحن تجريبي من وكيل', 'detail': 'اليوم • 10:25', 'amount': '+2,000 دج', 'state': 'تجريبي'},
  ];

  @override
  void dispose() { phone.dispose(); amount.dispose(); super.dispose(); }

  void requestFlexy() {
    final n = int.tryParse(amount.text.trim());
    if (phone.text.trim().length < 9 || n == null || n <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تحقق من رقم الهاتف والمبلغ.')));
      return;
    }
    showDialog<void>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('طلب تجريبي فقط'),
      content: const Text('هذه النسخة لا تتصل بسيرفر الموزّع ولا تنفّذ فليكسي حقيقيًا. لن يتم خصم الرصيد.'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('حسنًا'))],
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('FlexDZ • الزبون'), actions: [
        IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.logout)),
      ]),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF087F5B), Color(0xFF0B5D49)]),
            borderRadius: BorderRadius.circular(24),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('الرصيد التجريبي', style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 10),
            Text('$balance دج', style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold)),
            const SizedBox(height: 14),
            const Text('هذا الرصيد وهمي للعرض فقط', style: TextStyle(color: Colors.white70, fontSize: 12)),
          ]),
        ),
        const SizedBox(height: 22),
        const Text('إرسال فليكسي', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: network,
          decoration: const InputDecoration(labelText: 'شبكة الهاتف'),
          items: const ['موبيليس', 'جيزي', 'أوريدو'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
          onChanged: (v) => setState(() => network = v ?? network),
        ),
        const SizedBox(height: 12),
        TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'رقم الهاتف', hintText: '05 / 06 / 07 ...')),
        const SizedBox(height: 12),
        TextField(controller: amount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'المبلغ (دج)')),
        const SizedBox(height: 14),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: green, padding: const EdgeInsets.symmetric(vertical: 16)),
          onPressed: requestFlexy,
          child: const Text('متابعة (تجريبي)'),
        ),
        const SizedBox(height: 24),
        const Text('آخر العمليات', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        ...history.map((h) => Card(
          elevation: 0, color: Colors.white,
          child: ListTile(
            leading: const CircleAvatar(backgroundColor: mint, child: Icon(Icons.receipt_long, color: green)),
            title: Text(h['title']!), subtitle: Text(h['detail']!),
            trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text(h['amount']!, style: const TextStyle(fontWeight: FontWeight.bold)),
              Text(h['state']!, style: const TextStyle(color: Colors.orange, fontSize: 11)),
            ]),
          ),
        )),
      ]),
    );
  }
}

class AgentHome extends StatefulWidget {
  const AgentHome({super.key});
  @override
  State<AgentHome> createState() => _AgentHomeState();
}

class _AgentHomeState extends State<AgentHome> {
  final customer = TextEditingController();
  final amount = TextEditingController(text: '1000');
  @override
  void dispose() { customer.dispose(); amount.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('FlexDZ • الوكيل'), actions: [
        IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.logout)),
      ]),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(Icons.storefront, color: green, size: 32),
            SizedBox(height: 12),
            Text('رصيد الوكيل التجريبي', style: TextStyle(color: Colors.black54)),
            SizedBox(height: 6),
            Text('25,000 دج', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: ink)),
            SizedBox(height: 8),
            Text('الرصيد هنا وهمي، ولا يمثل رصيد موزّع حقيقيًا.', style: TextStyle(fontSize: 12, color: Colors.black45)),
          ]),
        ),
        const SizedBox(height: 24),
        const Text('إضافة رصيد لزبون', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        TextField(controller: customer, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'رقم حساب الزبون أو هاتفه')),
        const SizedBox(height: 12),
        TextField(controller: amount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'المبلغ المقبوض (دج)')),
        const SizedBox(height: 14),
        FilledButton.icon(
          style: FilledButton.styleFrom(backgroundColor: green, padding: const EdgeInsets.symmetric(vertical: 16)),
          onPressed: () => showDialog<void>(context: context, builder: (ctx) => AlertDialog(
            title: const Text('عملية تجريبية'),
            content: const Text('لن يتغير أي رصيد في هذه النسخة. يجب ربط الإضافة بخادم آمن وتسجيل العملية محاسبيًا قبل الاستخدام الحقيقي.'),
            actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('حسنًا'))],
          )),
          icon: const Icon(Icons.add_card),
          label: const Text('إضافة (تجريبي فقط)'),
        ),
        const SizedBox(height: 18),
        const Card(
          elevation: 0,
          child: ListTile(
            leading: Icon(Icons.verified_user_outlined, color: green),
            title: Text('صلاحيات الوكيل'),
            subtitle: Text('في النسخة الحقيقية، يجب اعتماد الوكيل من جهة مخوّلة، وتسجيل كل عملية والتحقق من الرصيد.'),
          ),
        ),
      ]),
    );
  }
}
